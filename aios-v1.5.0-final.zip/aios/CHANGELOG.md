# Changelog

## v1.5.0 (2026-04-11) — Production Release

### CLI
- 46 Python + 29 Go commands
- `deploy optimize` — vLLM flag auto-tuning (FP8, KV cache, TP)
- `deploy modelservice` — llm-d ModelService Helm values (3 presets)
- `deploy disagg` — P/D disaggregated deployment (NixlConnector/LMCacheConnector)
- Shell completion: bash, zsh, fish

### Runtime
- 29-model DB (DeepSeek V4 1T MoE, GLM-5, Gemma 4)
- 5 NPU vendors (NVIDIA, Intel, AMD, Huawei Ascend, Qualcomm)
- 7 GPU cost comparison (April 2026 pricing, B200: $0.89/Mtoken)
- Cloud fallback (5 providers: OpenAI, OpenRouter, Together, Groq, Fireworks)
- Speculative decoding (EAGLE3, MTP, N-gram)
- vLLM optimization flag generator (FP8 KV cache, chunked prefill, prefix caching)

### Structured Output
- 5 formats: guided_json, response_format, structured_outputs, Ollama format, Ollama schema
- Tool calling (OpenAI-compatible function calling)
- Mock engine generates schema-conforming JSON

### K8s Export (7 formats)
- KServe LLMInferenceService
- Gateway API InferencePool/InferenceModel v1
- KEDA ScaledObject
- HPA (autoscaling/v2)
- Dynamo DGDR (InferenceDeployment)
- llm-d P/D Disaggregation
- llm-d ModelService Helm values

### Monitoring
- OTel GenAI Semantic Conventions (gen_ai.* + aios.*)
- Grafana dashboard (8 panels)
- Prometheus alerting rules (9 rules, 3 groups)

### MCP Server (10 tools)
- JSON-RPC 2.0 over stdio
- Tools: health, status, recommend, cost, optimize, security, recipes, meter, lora, fabric

### Infrastructure
- Docker Compose quick start
- bootc Containerfile (Fedora 42)
- systemd service unit
- Makefile (20 targets)
- GitHub Actions CI (Python 3.11-3.13 + Go 1.23)

### Quality
- 676 tests (659 Python + 17 Go)
- 0 compile errors, 0 import errors, 0 bare excepts
- 81% return type hint coverage
- 99.7% docstring coverage
- PEP 561 py.typed marker

## v1.0.0 (2026-04-10) — Initial Release

- 46 CLI commands, 22 REST API endpoints
- Mock engine with OpenAI-compatible API
- 10 deployment recipes
- Hardware auto-detection (GPU/NPU/CPU)
- Cosign v3 model verification
- cgroup v2 process isolation
- Token metering and quota enforcement
