"""aictl spec — speculative decoding configuration."""

from __future__ import annotations

from aictl.core.output import ok, err, print_json, print_kv


def register(sub):
    """Register CLI subcommand and arguments."""
    p = sub.add_parser("spec", help="Speculative decoding configuration")
    ssub = p.add_subparsers(dest="spec_cmd")

    auto = ssub.add_parser("auto", help="Auto-select best method for a model")
    auto.add_argument("model", help="Model name (HF path)")
    auto.set_defaults(func=run_auto)

    vllm = ssub.add_parser("vllm", help="Generate vLLM speculative args")
    vllm.add_argument("model", help="Model name")
    vllm.set_defaults(func=run_vllm)

    sglang = ssub.add_parser("sglang", help="Generate SGLang speculative args")
    sglang.add_argument("model", help="Model name")
    sglang.set_defaults(func=run_sglang)

    drafts = ssub.add_parser("drafts", help="List known EAGLE3 draft models")
    drafts.set_defaults(func=run_drafts)

    p.set_defaults(func=lambda a: (p.print_help(), 0)[1])


def run_auto(args) -> int:
    """Execute the auto subcommand."""
    from aictl.runtime.speculative import auto_select_method, estimate_speedup

    config = auto_select_method(args.model)
    speedup = estimate_speedup(config)

    if getattr(args, "json", False):
        from dataclasses import asdict
        print_json({"config": asdict(config), "speedup": speedup})
        return 0

    ok(f"Speculative decoding for {args.model}")
    print_kv([
        ("Method", config.method.upper()),
        ("Draft model", config.draft_model or "(none)"),
        ("Spec tokens", str(config.num_speculative_tokens)),
        ("Parallel", "Yes" if config.parallel_drafting else "No"),
        ("Est. latency", f"{speedup['estimated_latency_speedup']:.1f}x"),
        ("Est. throughput", f"{speedup['estimated_throughput_speedup']:.1f}x"),
        ("Note", speedup["note"]),
    ], indent=2)
    return 0


def run_vllm(args) -> int:
    """Execute the vllm subcommand."""
    from aictl.runtime.speculative import auto_select_method, generate_vllm_args
    config = auto_select_method(args.model)
    vllm_args = generate_vllm_args(config)
    if vllm_args:
        print(f"vllm serve {args.model} \\")
        for a in vllm_args:
            print(f"  {a}")
    else:
        print(f"# No speculative decoding available for {args.model}")
    return 0


def run_sglang(args) -> int:
    """Execute the sglang subcommand."""
    from aictl.runtime.speculative import auto_select_method, generate_sglang_args
    config = auto_select_method(args.model)
    sglang_args = generate_sglang_args(config)
    if sglang_args:
        print(f"python3 -m sglang.launch_server --model {args.model} \\")
        for a in sglang_args:
            print(f"  {a}")
    else:
        print(f"# No speculative decoding available for {args.model}")
    return 0


def run_drafts(args) -> int:
    """Execute the drafts subcommand."""
    from aictl.runtime.speculative import EAGLE3_DRAFTS, MTP_MODELS

    if getattr(args, "json", False):
        print_json({"eagle3": EAGLE3_DRAFTS, "mtp": list(MTP_MODELS)})
        return 0

    ok(f"EAGLE3 draft models ({len(EAGLE3_DRAFTS)})")
    for base, draft in sorted(EAGLE3_DRAFTS.items()):
        print(f"  {base}")
        print(f"    → {draft}")

    print()
    ok(f"MTP-native models ({len(MTP_MODELS)})")
    for m in sorted(MTP_MODELS):
        print(f"  {m}")
    return 0
