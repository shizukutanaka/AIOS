"""aictl apply — apply a Stack manifest to start AI services.

Supports two modes:
  default:  Start services via podman run / ollama (immediate, ephemeral)
  --quadlet: Generate systemd Quadlet units (persistent, survives reboot)
"""

from __future__ import annotations

import time

from aictl.core.output import ok, err, warn, print_json, print_kv
from aictl.core.state import StateStore, StackEntry
from aictl.stack.manifest import parse_file, StackParseError
from aictl.stack.orchestrator import apply_stack
from aictl.stack.quadlet import generate_quadlets, write_quadlets, reload_systemd


def register(sub):
    """Register CLI subcommand and arguments."""
    p = sub.add_parser("apply", help="Apply a Stack manifest")
    p.add_argument("-f", "--file", required=True, help="Path to stack manifest")
    p.add_argument("--dry-run", action="store_true", help="Show plan without executing")
    p.add_argument("--quadlet", action="store_true",
                   help="Generate systemd Quadlet units (persistent)")
    p.add_argument("--root", action="store_true",
                   help="Install Quadlet units system-wide (requires root)")
    p.set_defaults(func=run)


def run(args) -> int:
    """Execute the apply command."""
    store = StateStore(getattr(args, "state_dir", None))
    try:
        manifest = parse_file(args.file)
    except StackParseError as e:
        err(str(e))
        return 1

    dry = getattr(args, "dry_run", False)
    quadlet = getattr(args, "quadlet", False)

    if quadlet:
        return _apply_quadlet(args, manifest, store, dry)
    return _apply_direct(args, manifest, store, dry)


def _apply_direct(args, manifest, store, dry) -> int:
    results = apply_stack(manifest, dry_run=dry)
    entry = StackEntry(
        name=manifest.name, file=args.file, applied_at=time.time(),
        status="running" if not dry else "dry-run",
        services=[{"name": r.name, "status": r.status, "endpoint": r.endpoint} for r in results],
    )
    if not dry:
        store.upsert_stack(entry)

    if getattr(args, "json", False):
        print_json({"stack": manifest.name, "mode": "direct",
                     "services": [r.__dict__ for r in results]})
        return 0

    label = "[DRY RUN] " if dry else ""
    ok(f"{label}Stack '{manifest.name}' applied (direct)")
    for r in results:
        icon = "\u2713" if r.status in ("running", "starting", "dry-run") else "\u2717"
        ep = f" \u2192 {r.endpoint}" if r.endpoint else ""
        detail = f" ({r.error})" if r.error else ""
        print(f"  {icon} {r.name} [{r.status}]{ep}{detail}")

    if not dry:
        from aictl.core.hooks import on_stack_applied
        on_stack_applied(manifest.name, args.file, mode="direct",
                         services=len(results), state_dir=store.dir)

    return 0


def _apply_quadlet(args, manifest, store, dry) -> int:
    rootless = not getattr(args, "root", False)
    units = generate_quadlets(manifest, rootless=rootless)
    if not units:
        warn("No container services to generate Quadlet units for")
        return 0

    if getattr(args, "json", False):
        print_json({"stack": manifest.name, "mode": "quadlet", "rootless": rootless,
                     "units": [{"filename": u.filename, "service": u.service_name} for u in units]})
        if dry:
            return 0

    written = write_quadlets(units, rootless=rootless, dry_run=dry)
    entry = StackEntry(
        name=manifest.name, file=args.file, applied_at=time.time(),
        status="quadlet-installed" if not dry else "dry-run",
        services=[{"name": u.service_name, "status": "installed"} for u in units],
    )
    if not dry:
        store.upsert_stack(entry)

    label = "[DRY RUN] " if dry else ""
    ok(f"{label}Stack '{manifest.name}' \u2014 {len(units)} Quadlet units")
    for u in units:
        print(f"  \u2713 {u.filename} \u2192 {u.service_name}")

    if dry:
        print("\nPreview:")
        for u in units:
            print(f"\n\u2500\u2500 {u.filename} \u2500\u2500")
            print(u.content)
    else:
        for p in written:
            print(f"  Written: {p}")
        if reload_systemd():
            ok("systemd daemon-reload complete")
        else:
            warn("Reload manually: systemctl --user daemon-reload")
    return 0
