"""aictl gate — automated quality gate for CI/CD and release validation."""

from __future__ import annotations

import importlib
import os
import sys
import time
import unittest
from pathlib import Path
from aictl.core.output import ok, err


def register(sub):
    """Register CLI subcommand and arguments."""
    p = sub.add_parser("gate", help="Run quality gate (compile + import + version + tests + demo)")
    p.add_argument("--skip-demo", action="store_true", help="Skip demo step")
    p.add_argument("--skip-tests", action="store_true", help="Skip test suite")
    p.set_defaults(func=run)


def run(args) -> int:
    """Execute the gate command."""
    results: list[tuple[str, bool, str]] = []
    t0 = time.monotonic()

    # 1. Compile check
    compile_errors = 0
    aictl_dir = Path(__file__).resolve().parent.parent
    for f in aictl_dir.rglob("*.py"):
        if "__pycache__" in str(f):
            continue
        try:
            import py_compile
            py_compile.compile(str(f), doraise=True)
        except py_compile.PyCompileError:
            compile_errors += 1
    results.append(("Compile", compile_errors == 0, f"{compile_errors} errors"))

    # 2. Import check
    import_errors = 0
    project_root = aictl_dir.parent
    sys.path.insert(0, str(project_root))
    for f in aictl_dir.rglob("*.py"):
        if "__pycache__" in str(f) or f.name == "__init__.py":
            continue
        mod_path = str(f.relative_to(project_root)).replace("/", ".").replace(".py", "")
        try:
            importlib.import_module(mod_path)
        except Exception:
            import_errors += 1
    results.append(("Import", import_errors == 0, f"{import_errors} errors"))

    # 3. Version consistency
    from aictl.__main__ import VERSION
    try:
        import tomllib
    except ImportError:
        tomllib = None
    toml_version = VERSION  # Assume match if can't read toml
    toml_path = project_root / "pyproject.toml"
    if toml_path.exists():
        for line in toml_path.read_text().splitlines():
            if line.startswith("version"):
                toml_version = line.split('"')[1]
                break
    match = VERSION == toml_version
    results.append(("Version", match, f"{VERSION} == {toml_version}"))

    # 4. Tests
    if not getattr(args, "skip_tests", False):
        tests_dir = project_root / "tests"
        loader = unittest.TestLoader()
        suite = loader.discover(str(tests_dir))
        runner = unittest.TextTestRunner(verbosity=0, stream=open(os.devnull, "w"))
        result = runner.run(suite)
        passed = result.testsRun - len(result.failures) - len(result.errors)
        results.append(("Tests", result.wasSuccessful(),
                        f"{passed}/{result.testsRun} passed"))
    else:
        results.append(("Tests", True, "skipped"))

    # 5. Demo
    if not getattr(args, "skip_demo", False):
        try:
            from aictl.daemon.mock_engine import start_mock_engine
            from aictl.daemon.aiosd import AIOSHandler, ThreadedHTTPServer
            from aictl.core.state import StateStore, NodeState
            import tempfile, json, urllib.request

            tmp = Path(tempfile.mkdtemp())
            store = StateStore(tmp)
            store.save_node(NodeState(node_id="gate", hostname="gate",
                                      profile="cpu-only", version=VERSION, ram_total_mb=16384))
            from aictl.core.constants import TEST_ENGINE_PORT, TEST_DAEMON_PORT
            mock = start_mock_engine(port=TEST_ENGINE_PORT)
            AIOSHandler.store = store
            daemon = ThreadedHTTPServer(("127.0.0.1", TEST_DAEMON_PORT), AIOSHandler)
            daemon._start_time = time.time()
            import threading
            threading.Thread(target=daemon.serve_forever, daemon=True).start()
            time.sleep(0.5)

            # Test engine
            with urllib.request.urlopen(f"http://127.0.0.1:{TEST_ENGINE_PORT}/health", timeout=3) as r:
                assert json.loads(r.read())["status"] == "ok"

            # Test daemon
            with urllib.request.urlopen(f"http://127.0.0.1:{TEST_DAEMON_PORT}/v1/health", timeout=3) as r:
                assert json.loads(r.read())["status"] == "ok"

            # Test completion
            body = json.dumps({"model": "mock", "messages": [{"role": "user", "content": "gate test"}]}).encode()
            req = urllib.request.Request(f"http://127.0.0.1:{TEST_ENGINE_PORT}/v1/chat/completions",
                                        data=body, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=10) as r:
                resp = json.loads(r.read())
                assert "choices" in resp

            mock.shutdown()
            daemon.shutdown()
            results.append(("Demo", True, "engine + daemon + completion"))
        except Exception as e:
            results.append(("Demo", False, str(e)[:60]))
    else:
        results.append(("Demo", True, "skipped"))

    # Output
    elapsed = time.monotonic() - t0
    all_pass = all(r[1] for r in results)

    if getattr(args, "json", False):
        from aictl.core.output import print_json
        print_json({"passed": all_pass, "checks": [
            {"name": n, "passed": p, "detail": d} for n, p, d in results
        ], "elapsed_s": round(elapsed, 1)})
        return 0

    print()
    for name, passed, detail in results:
        icon = "\u2713" if passed else "\u2717"
        print(f"  {icon} {name:12s} {detail}")

    print(f"\n  {'✓ GATE PASSED' if all_pass else '✗ GATE FAILED'} ({elapsed:.1f}s)")
    return 0 if all_pass else 1
