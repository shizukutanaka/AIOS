"""aictl setup — interactive first-time configuration wizard."""

from __future__ import annotations

import sys

from aictl.core.output import ok, warn, err, print_kv
from aictl.core.state import StateStore
from aictl.core.config import Config, save_config, load_config
from aictl.runtime.broker import full_detect
from aictl.runtime.recommend import recommend


def register(sub):
    """Register CLI subcommand and arguments."""
    p = sub.add_parser("setup", help="Interactive setup wizard")
    p.set_defaults(func=run)


def run(args) -> int:
    """Execute the setup command."""
    print()
    print("  AI Native Linux OS — Setup Wizard")
    print("  " + "=" * 36)
    print()

    store = StateStore(getattr(args, "state_dir", None))

    # Step 1: Detect hardware
    print("Step 1: Detecting hardware...")
    report = full_detect()
    vram = sum(g.vram_mb for g in report.gpus)

    print_kv([
        ("CPU", f"{report.system.cpu_model} ({report.system.cpu_cores} cores)"),
        ("RAM", f"{report.system.ram_total_mb} MB"),
        ("GPUs", f"{len(report.gpus)} ({vram} MB VRAM)" if report.gpus else "None"),
        ("Profile", report.profile),
        ("Container RT", report.container_runtime or "none"),
    ], indent=2)
    print()

    # Step 2: Issues
    if report.issues:
        warn("Issues detected:")
        for issue in report.issues:
            print(f"    {issue}")
        print()

    # Step 3: Recommendations
    if report.recommendations:
        print("  Recommendations:")
        for rec in report.recommendations:
            print(f"    \u2192 {rec}")
        print()

    # Step 4: Model recommendations
    recs = recommend(vram_mb=vram, ram_mb=report.system.ram_total_mb, max_results=3)
    if recs:
        print("  Recommended models for your hardware:")
        for r in recs:
            gpu_tag = f" [{r.vram_required_mb}MB VRAM]" if r.vram_required_mb > 0 else ""
            print(f"    \u2022 {r.name} ({r.use_case}){gpu_tag}")
            print(f"      {r.notes}")
        print()

    # Step 5: Initialize
    if not store.is_initialized():
        print("  Initializing node...")
        from aictl.cmd.init import run as init_run
        # Create a minimal args object
        class InitArgs:
            force = False
            json = False
            state_dir = getattr(args, "state_dir", None)
        init_run(InitArgs())
    else:
        ok("Node already initialized")

    # Step 6: Save default config
    config = load_config(store.dir)
    save_config(config, store.dir)
    ok("Default configuration saved")

    # Step 7: Next steps
    print()
    print("  Next steps:")
    if report.container_runtime == "none":
        print("    1. Install podman: sudo dnf install podman")
        print("    2. Run: aictl recipe run local-chat")
    elif recs:
        best = recs[0]
        if best.runtime == "ollama":
            print(f"    1. Install Ollama: curl -fsSL https://ollama.com/install.sh | sh")
            print(f"    2. Run: aictl recipe run local-chat")
        else:
            print(f"    1. Run: aictl recipe run local-gpu-chat")
    else:
        print("    1. Run: aictl recipe list")
    print("    3. Run: aictl status")
    print()

    return 0
