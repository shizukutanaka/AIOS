"""aictl status — unified system status view."""

from __future__ import annotations

from aictl.core.output import ok, err, warn, print_json, print_kv, print_table
from aictl.core.state import StateStore
from aictl.core.config import load_config
from aictl.runtime.broker import full_detect
from aictl.runtime.adapters import discover_engines
from aictl.runtime.nodes import NodeManager
from aictl.stack.orchestrator import list_running
from aictl.metrics.slo import read_psi


def register(sub):
    """Register CLI subcommand and arguments."""
    p = sub.add_parser("status", help="Unified system status")
    p.set_defaults(func=run)


def run(args) -> int:
    """Execute the status command."""
    store = StateStore(getattr(args, "state_dir", None))
    config = load_config(store.dir)
    node = store.load_node()
    report = full_detect()
    stacks = store.load_stacks()
    services = list_running()
    psi = read_psi()

    if getattr(args, "json", False):
        from dataclasses import asdict
        print_json({
            "node": asdict(node),
            "profile": report.profile,
            "gpus": len(report.gpus),
            "services": len(services),
            "stacks": len(stacks),
            "psi_memory": psi.memory_some_avg10,
        })
        return 0

    # Header
    status_icon = "\u2713" if store.is_initialized() else "\u2717"
    print(f"{status_icon} AI OS — {node.hostname or 'not initialized'}")
    print()

    # Quick stats
    print_kv([
        ("Profile", report.profile),
        ("GPUs", f"{len(report.gpus)} ({sum(g.vram_mb for g in report.gpus)} MB VRAM)"),
        ("RAM", f"{report.system.ram_total_mb} MB"),
        ("Container RT", report.container_runtime or "none"),
        ("Stacks", str(len(stacks))),
        ("Services", str(len(services))),
    ])

    # PSI
    if report.system.psi_enabled:
        print()
        mem_status = "ok" if psi.memory_some_avg10 < 25 else "warn"
        icon = "\u2713" if mem_status == "ok" else "\u26a0"
        print(f"  {icon} Memory pressure: {psi.memory_some_avg10:.1f}% (some avg10)")

    # Engines
    engines = discover_engines(config.engines.to_dict())
    online = [e for e in engines if e.reachable]
    if online:
        print(f"\n  Engines online: {', '.join(e.engine for e in online)}")
    else:
        print(f"\n  Engines: none reachable")

    # Cluster
    mgr = NodeManager(store)
    cs = mgr.load_cluster()
    if cs.peers:
        active = sum(1 for p in cs.peers if p.status == "active")
        print(f"  Cluster: {cs.mode} ({active}/{len(cs.peers)} peers)")

    # Issues
    if report.issues:
        print()
        for issue in report.issues:
            err(f"  {issue}")

    return 0
