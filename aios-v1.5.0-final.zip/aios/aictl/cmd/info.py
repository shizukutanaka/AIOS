"""aictl info — project information and system summary."""

from __future__ import annotations
from aictl.core.output import ok, print_json, print_kv


def register(sub):
    """Register CLI subcommand and arguments."""
    p = sub.add_parser("info", help="Project information")
    p.set_defaults(func=run)


def run(args) -> int:
    """Execute the info command."""
    from aictl.__main__ import VERSION
    from aictl.stack.manifest import list_recipes
    from aictl.runtime.recommend import MODELS

    info = {
        "name": "AI Native Linux OS",
        "binary": "aictl",
        "version": VERSION,
        "python_commands": 46,
        "go_commands": 29,
        "rest_endpoints": 22,
        "recipes": len(list_recipes()),
        "model_db": len(MODELS),
        "skills": 8,
        "tests": "647+",
        "stack": [
            "bootc v1.15 (Fedora 42)", "Podman + Quadlet",
            "vLLM v0.19 / SGLang v0.5 / Ollama v0.20",
            "K3s v1.35 + KServe v0.17 + llm-d v0.5",
            "NVIDIA Dynamo v0.8 (KVBM + NIXL)",
            "Gateway API InferencePool v1",
            "KEDA v2.19", "Cosign v3 + ORAS",
            "OTel GenAI SemConv v1.40 + Prometheus",
        ],
        "os_features": [
            "Fabric Memory Orchestrator (DRAM/CXL/NVMe)",
            "Attested Model Vault (Cosign v3)",
            "QoS Slice Broker + SLO Governor",
            "Context Continuity Engine",
            "Token Metering + Quota Enforcement",
            "Process Isolation (cgroup v2 OOM protection)",
            "LoRA Adapter Management",
            "NVIDIA Dynamo KVBM + NIXL",
        ],
    }

    if getattr(args, "json", False):
        print_json(info)
        return 0

    ok(f"aictl {info['version']}")
    print()
    print_kv([
        ("Commands", f"{info['python_commands']} Python + {info['go_commands']} Go"),
        ("REST API", f"{info['rest_endpoints']} endpoints"),
        ("Recipes", str(info['recipes'])),
        ("Models", str(info['model_db'])),
        ("Tests", info['tests']),
        ("Skills", str(info['skills'])),
    ], indent=2)

    print("\n  Stack:")
    for s in info["stack"]:
        print(f"    {s}")

    print("\n  OS Features:")
    for f in info["os_features"]:
        print(f"    \u2713 {f}")

    return 0
