"""aictl config — view and modify persistent configuration."""

from __future__ import annotations

import json
from pathlib import Path

from aictl.core.output import ok, err, print_json, print_kv
from aictl.core.config import Config, load_config, save_config
from aictl.core.state import StateStore


def register(sub):
    """Register CLI subcommand and arguments."""
    p = sub.add_parser("config", help="View or modify configuration")
    csub = p.add_subparsers(dest="config_cmd")

    show = csub.add_parser("show", help="Show current config")
    show.set_defaults(func=run_show)

    st = csub.add_parser("set", help="Set a config value")
    st.add_argument("key", help="Dot-separated key (e.g. engines.vllm)")
    st.add_argument("value", help="New value")
    st.set_defaults(func=run_set)

    reset = csub.add_parser("reset", help="Reset config to defaults")
    reset.set_defaults(func=run_reset)

    p.set_defaults(func=lambda a: (p.print_help(), 0)[1])


def run_show(args) -> int:
    """Execute the show subcommand."""
    state_dir = Path(args.state_dir) if getattr(args, "state_dir", None) else None
    config = load_config(state_dir)
    from dataclasses import asdict
    if getattr(args, "json", False):
        print_json(asdict(config))
        return 0

    d = asdict(config)
    _print_nested(d)
    return 0


def run_set(args) -> int:
    """Execute the set subcommand."""
    state_dir = Path(args.state_dir) if getattr(args, "state_dir", None) else None
    config = load_config(state_dir)
    from dataclasses import asdict

    parts = args.key.split(".")
    d = asdict(config)

    # Navigate to parent
    obj = d
    for part in parts[:-1]:
        if part not in obj or not isinstance(obj[part], dict):
            err(f"Unknown key: {args.key}")
            return 1
        obj = obj[part]

    last = parts[-1]
    if last not in obj:
        err(f"Unknown key: {args.key}")
        return 1

    # Type coerce
    old_val = obj[last]
    if isinstance(old_val, bool):
        obj[last] = args.value.lower() in ("true", "1", "yes")
    elif isinstance(old_val, int):
        obj[last] = int(args.value)
    elif isinstance(old_val, float):
        obj[last] = float(args.value)
    else:
        obj[last] = args.value

    # Rebuild config
    config = _dict_to_config(d)
    save_config(config, state_dir)
    ok(f"{args.key} = {obj[last]}")
    return 0


def run_reset(args) -> int:
    """Execute the reset subcommand."""
    state_dir = Path(args.state_dir) if getattr(args, "state_dir", None) else None
    save_config(Config(), state_dir)
    ok("Config reset to defaults")
    return 0


def _print_nested(d, prefix=""):
    for k, v in d.items():
        key = f"{prefix}{k}" if not prefix else f"{prefix}.{k}"
        if isinstance(v, dict):
            _print_nested(v, key)
        else:
            print(f"  {key} = {v}")


def _dict_to_config(d: dict) -> Config:
    from aictl.core.config import EngineEndpoints, SLOConfig, DaemonConfig
    return Config(
        engines=EngineEndpoints(**d.get("engines", {})),
        slo=SLOConfig(**{k: v for k, v in d.get("slo", {}).items() if k in SLOConfig.__dataclass_fields__}),
        daemon=DaemonConfig(**d.get("daemon", {})),
        trust_policy=d.get("trust_policy", "warn"),
        quadlet_rootless=d.get("quadlet_rootless", True),
        default_recipe=d.get("default_recipe", "local-chat"),
        model_cache_dir=d.get("model_cache_dir", ""),
        log_level=d.get("log_level", "info"),
    )
