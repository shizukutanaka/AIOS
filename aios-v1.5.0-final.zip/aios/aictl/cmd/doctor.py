"""aictl doctor — comprehensive system diagnosis for AI workloads.

Combines: hardware detection, security scan, memory fabric, network check,
engine reachability, and recommendations into a single report.
"""

from __future__ import annotations

from aictl.core.output import ok, warn, err, print_json, print_kv
from aictl.core.state import StateStore
from aictl.runtime.broker import full_detect


def register(sub):
    """Register CLI subcommand and arguments."""
    p = sub.add_parser("doctor", help="Comprehensive system diagnosis")
    p.add_argument("--deep", action="store_true", help="Include security + fabric + network")
    p.set_defaults(func=run)


def run(args) -> int:
    """Execute the doctor command."""
    store = StateStore(getattr(args, "state_dir", None))
    report = full_detect()
    deep = getattr(args, "deep", False)

    if getattr(args, "json", False):
        result = {"hardware": report.__dict__}
        if deep:
            from aictl.core.security import scan
            from aictl.runtime.fabric import detect_memory_fabric
            from dataclasses import asdict
            result["security"] = asdict(scan(store.dir))
            result["fabric"] = asdict(detect_memory_fabric())
        print_json(result)
        return 0

    # ── Hardware ──────────────────────────────────────
    print("System")
    print_kv([
        ("Hostname", report.system.hostname),
        ("Kernel", report.system.kernel),
        ("CPU", f"{report.system.cpu_model} ({report.system.cpu_cores} cores)"),
        ("RAM", f"{report.system.ram_total_mb} MB"),
        ("Disk free", f"{report.system.disk_free_gb:.1f} GB"),
    ], indent=2)

    # ── Checks ────────────────────────────────────────
    checks_pass = 0
    checks_total = 0

    print("\nChecks")
    for label, passed, detail in [
        ("cgroup v2", report.system.cgroup_v2, ""),
        ("PSI (pressure stall)", report.system.psi_enabled, ""),
        ("Container runtime", report.container_runtime != "none", report.container_runtime or "not found"),
        ("Ollama", report.ollama_available, ""),
        ("Node initialized", store.is_initialized(), ""),
    ]:
        checks_total += 1
        if passed:
            checks_pass += 1
        icon = "\u2713" if passed else "\u2717"
        suffix = f" ({detail})" if detail else ""
        print(f"  {icon} {label}{suffix}")

    # ── GPUs ──────────────────────────────────────────
    if report.gpus:
        print(f"\nGPUs ({len(report.gpus)})")
        for g in report.gpus:
            mig = " [MIG enabled]" if g.mig_enabled else (" [MIG capable]" if g.mig_capable else "")
            print(f"  [{g.index}] {g.name} \u2014 {g.vram_mb} MB \u2014 {g.vendor} {g.driver_version}{mig}")
    else:
        print("\nGPUs: none")

    if report.npus:
        print(f"\nNPUs ({len(report.npus)})")
        for n in report.npus:
            print(f"  {n.name} \u2014 {n.vendor} \u2014 {n.runtime}")

    print(f"\nProfile: {report.profile}")

    # ── Deep checks ───────────────────────────────────
    if deep:
        # Security
        from aictl.core.security import scan
        sec = scan(store.dir)
        score_icon = "\u2713" if sec.score >= 80 else ("\u26a0" if sec.score >= 50 else "\u2717")
        print(f"\nSecurity: {score_icon} {sec.score}/100 ({sec.checks_passed}/{sec.checks_total} passed)")
        for f in sec.findings[:3]:
            print(f"  {f.severity.upper():8s} {f.title}")

        # Fabric
        from aictl.runtime.fabric import detect_memory_fabric
        fabric = detect_memory_fabric()
        print(f"\nMemory: {fabric.total_capacity_gb:.1f} GB across {len(fabric.tiers)} tiers")
        for t in fabric.tiers:
            print(f"  {t.name.upper():5s} {t.capacity_gb:.1f} GB ({t.available_gb:.1f} GB free)")
        if fabric.damon_available:
            print("  DAMON: available")
        if fabric.cxl_detected:
            print("  CXL: detected")

        # Network
        from aictl.core.config import load_config
        config = load_config(store.dir)
        endpoints = config.engines.to_dict()
        print(f"\nEngines")
        import socket, time
        for name, url in endpoints.items():
            host = url.replace("http://", "").replace("https://", "").split(":")[0]
            port_str = url.replace("http://", "").replace("https://", "").split(":")[-1].split("/")[0]
            try:
                port = int(port_str)
                t0 = time.monotonic()
                sock = socket.create_connection((host, port), timeout=2)
                sock.close()
                ms = (time.monotonic() - t0) * 1000
                print(f"  \u2713 {name:10s} {url} ({ms:.0f}ms)")
                checks_pass += 1
            except Exception:
                print(f"  \u2717 {name:10s} {url} (unreachable)")
            checks_total += 1

    # ── Summary ───────────────────────────────────────
    if report.issues:
        print("\nIssues")
        for issue in report.issues:
            print(f"  \u2717 {issue}")

    if report.recommendations:
        print("\nRecommendations")
        for rec in report.recommendations:
            print(f"  \u2192 {rec}")

    if not deep:
        print(f"\n  Run 'aictl doctor --deep' for security + fabric + network checks")

    return 0
