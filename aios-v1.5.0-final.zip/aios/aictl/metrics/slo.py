"""AI workload metrics schema and collector interface.

Defines the standard metrics for SLO monitoring:
  - TTFT (Time To First Token) — ms
  - ITL  (Inter-Token Latency) — ms
  - TPOT (Time Per Output Token) — ms
  - tokens_per_sec — throughput
  - queue_depth — pending requests
  - vram_used_mb / vram_total_mb
  - kv_cache_utilization — 0.0–1.0
  - error_rate — 0.0–1.0
  - psi_memory — PSI some/full avg10
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass, field


@dataclass
class InferenceMetrics:
    timestamp: float = 0.0
    engine: str = ""           # vllm | sglang | ollama | trt-llm
    model: str = ""
    ttft_ms_p50: float = 0.0
    ttft_ms_p95: float = 0.0
    ttft_ms_p99: float = 0.0
    itl_ms_p50: float = 0.0
    itl_ms_p95: float = 0.0
    tpot_ms: float = 0.0
    tokens_per_sec: float = 0.0
    queue_depth: int = 0
    active_requests: int = 0
    vram_used_mb: int = 0
    vram_total_mb: int = 0
    kv_cache_utilization: float = 0.0
    error_rate: float = 0.0


@dataclass
class SystemPressure:
    """Linux PSI (Pressure Stall Information)."""
    memory_some_avg10: float = 0.0
    memory_some_avg60: float = 0.0
    memory_full_avg10: float = 0.0
    memory_full_avg60: float = 0.0
    cpu_some_avg10: float = 0.0
    io_some_avg10: float = 0.0


@dataclass
class SLOTarget:
    """SLO targets for automated governance."""
    ttft_p95_ms: float = 500.0
    itl_p95_ms: float = 50.0
    tokens_per_sec_min: float = 10.0
    error_rate_max: float = 0.05
    queue_depth_max: int = 100
    kv_cache_max: float = 0.9
    psi_memory_some_max: float = 25.0   # percentage


@dataclass
class SLOVerdict:
    """SLO check result."""
    compliant: bool = True
    violations: list[str] = field(default_factory=list)
    action: str = "none"  # none | scale_batch | drain | failover


def read_psi() -> SystemPressure:
    """Read Linux PSI from /proc/pressure/."""
    sp = SystemPressure()
    for resource, prefix in [("memory", "memory"), ("cpu", "cpu"), ("io", "io")]:
        path = f"/proc/pressure/{resource}"
        if not os.path.exists(path):
            continue
        try:
            with open(path) as f:
                for line in f:
                    if line.startswith("some"):
                        parts = line.split()
                        for p in parts:
                            if p.startswith("avg10="):
                                val = float(p.split("=")[1])
                                if resource == "memory":
                                    sp.memory_some_avg10 = val
                                elif resource == "cpu":
                                    sp.cpu_some_avg10 = val
                                elif resource == "io":
                                    sp.io_some_avg10 = val
                            elif p.startswith("avg60="):
                                val = float(p.split("=")[1])
                                if resource == "memory":
                                    sp.memory_some_avg60 = val
                    elif line.startswith("full"):
                        parts = line.split()
                        for p in parts:
                            if p.startswith("avg10="):
                                val = float(p.split("=")[1])
                                if resource == "memory":
                                    sp.memory_full_avg10 = val
                            elif p.startswith("avg60="):
                                val = float(p.split("=")[1])
                                if resource == "memory":
                                    sp.memory_full_avg60 = val
        except (OSError, ValueError):
            pass
    return sp


def check_slo(metrics: InferenceMetrics, pressure: SystemPressure,
              target: SLOTarget) -> SLOVerdict:
    """Check if current metrics meet SLO targets."""
    v = SLOVerdict()

    if metrics.ttft_ms_p95 > target.ttft_p95_ms:
        v.violations.append(f"TTFT p95 {metrics.ttft_ms_p95:.0f}ms > {target.ttft_p95_ms:.0f}ms")
    if metrics.itl_ms_p95 > target.itl_p95_ms:
        v.violations.append(f"ITL p95 {metrics.itl_ms_p95:.0f}ms > {target.itl_p95_ms:.0f}ms")
    if metrics.tokens_per_sec < target.tokens_per_sec_min and metrics.active_requests > 0:
        v.violations.append(f"Throughput {metrics.tokens_per_sec:.1f} t/s < {target.tokens_per_sec_min:.1f} t/s")
    if metrics.error_rate > target.error_rate_max:
        v.violations.append(f"Error rate {metrics.error_rate:.1%} > {target.error_rate_max:.1%}")
    if metrics.queue_depth > target.queue_depth_max:
        v.violations.append(f"Queue depth {metrics.queue_depth} > {target.queue_depth_max}")
    if metrics.kv_cache_utilization > target.kv_cache_max:
        v.violations.append(f"KV cache {metrics.kv_cache_utilization:.1%} > {target.kv_cache_max:.1%}")
    if pressure.memory_some_avg10 > target.psi_memory_some_max:
        v.violations.append(f"PSI memory {pressure.memory_some_avg10:.1f}% > {target.psi_memory_some_max:.1f}%")

    v.compliant = len(v.violations) == 0

    # Determine action
    if not v.compliant:
        critical = any("Error rate" in v or "PSI" in v for v in v.violations)
        if critical:
            v.action = "failover"
        elif len(v.violations) >= 3:
            v.action = "drain"
        else:
            v.action = "scale_batch"

    return v
