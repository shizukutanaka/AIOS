"""aictl MCP Server — Model Context Protocol interface.

Exposes aictl's infrastructure management tools to MCP clients
(Claude Desktop, Cursor, VS Code, custom agents).

MCP (Anthropic, donated to Linux Foundation AAIF Dec 2025) is the
de facto standard for LLM ↔ tool integration. This server lets
any MCP-compatible AI assistant manage local inference infrastructure.

Transport: JSON-RPC 2.0 over stdio (stdin/stdout)
Spec: https://modelcontextprotocol.io/specification/2025-11-25

Tools exposed:
  aictl_health       — System health check
  aictl_recommend    — Hardware-aware model recommendations
  aictl_models       — List available/running models
  aictl_cost         — GPU cost comparison
  aictl_deploy       — Deploy a recipe
  aictl_optimize     — Generate optimal vLLM flags
  aictl_status       — Node status and profile
  aictl_security     — Security scan

Usage:
  # In Claude Desktop config (~/.config/claude/mcp_servers.json):
  {
    "aictl": {
      "command": "python3",
      "args": ["-m", "aictl.mcp_server"]
    }
  }
"""

from __future__ import annotations

import json
import sys
from typing import Any


# ── MCP Protocol Constants ──
JSONRPC_VERSION = "2.0"
MCP_PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "aictl"
SERVER_VERSION = "1.5.0"


# ── Tool Definitions ──
TOOLS = [
    {
        "name": "aictl_health",
        "description": "Check AI OS system health: daemon status, GPU detection, container runtime, security score",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "aictl_recommend",
        "description": "Recommend AI models that fit current hardware (VRAM, RAM). Returns top models with runtime and VRAM requirements",
        "inputSchema": {
            "type": "object",
            "properties": {
                "use_case": {
                    "type": "string",
                    "description": "Filter: chat, code, embedding, vision, stt",
                    "enum": ["", "chat", "code", "embedding", "vision", "stt"],
                },
                "max_results": {"type": "integer", "default": 5},
            },
        },
    },
    {
        "name": "aictl_cost",
        "description": "Compare GPU cloud vs on-prem costs (RTX 4090, A100, H100, H200, B200, GB200). Returns monthly cost, break-even, cost per million tokens",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "aictl_optimize",
        "description": "Generate optimal vLLM serve flags for a model and GPU. Handles KV cache quantization, tensor parallelism, chunked prefill",
        "inputSchema": {
            "type": "object",
            "properties": {
                "model": {"type": "string", "description": "Model name (e.g. meta-llama/Llama-3.1-8B-Instruct)"},
                "model_size_b": {"type": "number", "description": "Model size in billions of parameters"},
                "gpu": {"type": "string", "description": "GPU type (H100, B200, RTX 4090, etc.)"},
                "gpu_count": {"type": "integer", "default": 1},
                "objective": {"type": "string", "enum": ["balanced", "throughput", "interactivity"]},
            },
            "required": ["model", "model_size_b"],
        },
    },
    {
        "name": "aictl_security",
        "description": "Run security scan on the AI OS installation. Returns score (0-100) and findings with remediation steps",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "aictl_status",
        "description": "Get node status: hostname, GPU profile, container runtime, OS info",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "aictl_recipes",
        "description": "List available deployment recipes (local-chat, team-rag, code-assist, etc.)",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "aictl_meter",
        "description": "Get token usage and cost per API key/tenant. Shows prompt/completion tokens, daily usage, and estimated cost",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "aictl_lora",
        "description": "List registered LoRA adapters and VRAM budget for base models",
        "inputSchema": {
            "type": "object",
            "properties": {
                "base_model": {"type": "string", "default": "", "description": "Filter by base model"},
            },
        },
    },
    {
        "name": "aictl_fabric",
        "description": "Detect memory fabric tiers (DRAM/CXL/NVMe) and placement policy for AI workloads",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
]


# ── Tool Handlers ──
def handle_tool(name: str, arguments: dict) -> dict:
    """Execute a tool and return MCP result."""
    try:
        if name == "aictl_health":
            return _tool_health()
        elif name == "aictl_recommend":
            return _tool_recommend(arguments)
        elif name == "aictl_cost":
            return _tool_cost()
        elif name == "aictl_optimize":
            return _tool_optimize(arguments)
        elif name == "aictl_security":
            return _tool_security()
        elif name == "aictl_status":
            return _tool_status()
        elif name == "aictl_recipes":
            return _tool_recipes()
        elif name == "aictl_meter":
            return _tool_meter()
        elif name == "aictl_lora":
            return _tool_lora(arguments)
        elif name == "aictl_fabric":
            return _tool_fabric()
        else:
            return {"content": [{"type": "text", "text": f"Unknown tool: {name}"}], "isError": True}
    except Exception as e:
        return {"content": [{"type": "text", "text": f"Error: {e}"}], "isError": True}


def _tool_health():
    from aictl.runtime.broker import full_detect
    from aictl.core.security import scan
    hw = full_detect()
    sec = scan()
    return {"content": [{"type": "text", "text": json.dumps({
        "profile": hw.profile,
        "gpus": len(hw.gpus),
        "npus": len(hw.npus),
        "container_runtime": hw.container_runtime,
        "ram_mb": hw.system.ram_total_mb,
        "security_score": sec.score,
        "security_passed": f"{sec.checks_passed}/{sec.checks_total}",
    }, indent=2)}]}


def _tool_recommend(args):
    from aictl.runtime.recommend import recommend
    from aictl.runtime.broker import full_detect
    hw = full_detect()
    vram = sum(g.vram_mb for g in hw.gpus)
    recs = recommend(
        vram_mb=vram,
        ram_mb=hw.system.ram_total_mb,
        use_case=args.get("use_case", ""),
        max_results=args.get("max_results", 5),
    )
    return {"content": [{"type": "text", "text": json.dumps([
        {"name": r.name, "runtime": r.runtime, "vram_mb": r.vram_required_mb,
         "use_case": r.use_case, "context_length": r.context_length, "notes": r.notes}
        for r in recs
    ], indent=2)}]}


def _tool_cost():
    from aictl.core.cost import compare_gpus
    from dataclasses import asdict
    results = compare_gpus()
    return {"content": [{"type": "text", "text": json.dumps([
        {"gpu": r.gpu_type, "cloud_monthly": round(r.cloud_monthly_usd),
         "onprem_monthly": round(r.onprem_monthly_usd),
         "break_even_months": round(r.break_even_months),
         "cost_per_million_tokens": round(r.cost_per_million_tokens, 4),
         "recommendation": r.recommendation}
        for r in results
    ], indent=2)}]}


def _tool_optimize(args):
    from aictl.runtime.optimize import optimize_vllm_flags, flags_to_command, HardwareProfile, GPU_CC
    gpu = args.get("gpu", "H100")
    profile = HardwareProfile(
        gpu_name=gpu,
        gpu_count=args.get("gpu_count", 1),
        vram_per_gpu_mb={"H100": 81920, "B200": 196608, "A100": 81920,
                         "RTX 4090": 24576}.get(gpu, 24576),
        compute_capability=GPU_CC.get(gpu, 90),
    )
    result = optimize_vllm_flags(
        model=args["model"],
        model_size_b=args["model_size_b"],
        hardware=profile,
        objective=args.get("objective", "balanced"),
    )
    return {"content": [{"type": "text", "text": json.dumps({
        "command": flags_to_command(result),
        "flags": result.flags,
        "estimated_throughput_tps": result.estimated_throughput_tps,
        "kv_cache_dtype": result.kv_cache_dtype,
        "tensor_parallel": result.tensor_parallel,
        "notes": result.notes,
    }, indent=2)}]}


def _tool_security():
    from aictl.core.security import scan
    from dataclasses import asdict
    report = scan()
    return {"content": [{"type": "text", "text": json.dumps({
        "score": report.score,
        "passed": report.checks_passed,
        "total": report.checks_total,
        "findings": [{"severity": f.severity, "title": f.title,
                      "remediation": f.remediation} for f in report.findings],
    }, indent=2)}]}


def _tool_status():
    from aictl.runtime.broker import full_detect
    hw = full_detect()
    return {"content": [{"type": "text", "text": json.dumps({
        "hostname": hw.system.hostname,
        "kernel": hw.system.kernel,
        "cpu": f"{hw.system.cpu_model} ({hw.system.cpu_cores} cores)",
        "ram_mb": hw.system.ram_total_mb,
        "profile": hw.profile,
        "container_runtime": hw.container_runtime,
        "gpus": [{"name": g.name, "vram_mb": g.vram_mb} for g in hw.gpus],
        "npus": [{"name": n.name, "vendor": n.vendor} for n in hw.npus],
    }, indent=2)}]}


def _tool_recipes():
    from aictl.stack.manifest import list_recipes, get_recipe
    recipes = []
    for name in list_recipes():
        r = get_recipe(name)
        if r:
            recipes.append({
                "name": name,
                "services": len(r.services),
                "gpu_required": any(s.gpu_required for s in r.services),
            })
    return {"content": [{"type": "text", "text": json.dumps(recipes, indent=2)}]}


def _tool_meter():
    from aictl.core.metering import TokenMeter
    from dataclasses import asdict
    meter = TokenMeter()
    buckets = meter.list_usage()
    data = {
        "entities": [asdict(b) for b in buckets],
        "total_tokens": sum(b.total_tokens for b in buckets),
        "total_entities": len(buckets),
    }
    return {"content": [{"type": "text", "text": json.dumps(data, indent=2)}]}


def _tool_lora(args: dict):
    from aictl.runtime.lora import LoRAManager
    from dataclasses import asdict
    mgr = LoRAManager()
    adapters = mgr.list_adapters(base_model=args.get("base_model", ""))
    return {"content": [{"type": "text", "text": json.dumps(
        [asdict(a) for a in adapters], indent=2
    )}]}


def _tool_fabric():
    from aictl.runtime.fabric import detect_memory_fabric, generate_placement_policy
    from dataclasses import asdict
    fabric = detect_memory_fabric()
    policy = generate_placement_policy(fabric)
    return {"content": [{"type": "text", "text": json.dumps({
        "tiers": [{"name": t.name, "capacity_gb": t.capacity_gb,
                   "available_gb": t.available_gb, "bandwidth_gbps": t.bandwidth_gbps}
                  for t in fabric.tiers],
        "total_gb": round(fabric.total_capacity_gb, 1),
        "damon": fabric.damon_available,
        "cxl": fabric.cxl_detected,
        "placement": asdict(policy),
    }, indent=2)}]}


# ── JSON-RPC 2.0 Handler ──
def handle_request(request: dict) -> dict | None:
    """Handle a single JSON-RPC 2.0 request."""
    method = request.get("method", "")
    req_id = request.get("id")
    params = request.get("params", {})

    if method == "initialize":
        return _response(req_id, {
            "protocolVersion": MCP_PROTOCOL_VERSION,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
        })

    elif method == "initialized":
        return None  # Notification, no response

    elif method == "tools/list":
        return _response(req_id, {"tools": TOOLS})

    elif method == "tools/call":
        name = params.get("name", "")
        arguments = params.get("arguments", {})
        result = handle_tool(name, arguments)
        return _response(req_id, result)

    elif method == "ping":
        return _response(req_id, {})

    else:
        return _error(req_id, -32601, f"Method not found: {method}")


def _response(req_id: Any, result: Any) -> dict:
    return {"jsonrpc": JSONRPC_VERSION, "id": req_id, "result": result}


def _error(req_id: Any, code: int, message: str) -> dict:
    return {"jsonrpc": JSONRPC_VERSION, "id": req_id,
            "error": {"code": code, "message": message}}


# ── Main Loop (stdio transport) ──
def main():
    """Run MCP server on stdio."""
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            response = handle_request(request)
            if response is not None:
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()
        except json.JSONDecodeError:
            err = _error(None, -32700, "Parse error")
            sys.stdout.write(json.dumps(err) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
