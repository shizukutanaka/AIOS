#!/usr/bin/env python3
"""aictl — AI Native Linux OS control CLI.

Covers MVP milestones M0–M3:
  M0: CLI skeleton (init, doctor, ps)
  M1: Single-node initialisation + hardware detection
  M2: Stack / Recipe system
  M3: Runtime Broker (GPU/NPU/CPU detection + profile selection)
"""

from __future__ import annotations

import argparse
import sys

from aictl.cmd import (
    doctor, init, ps, apply, down, recipe, upgrade, model, serve, node,
    logs, config, status, snapshot, cluster, otel, recommend, bench,
    setup, watch, proxy, warmup, net, mig, audit, apikey, image,
    fabric, context, scale, trace, tenant, cost, security, convert, deploy,
    completion, selftest, demo, chat, health, info, report, meter, lora, gate, spec,
)
from aictl.cmd import log as log_cmd


from aictl.core.constants import AICTL_VERSION
VERSION = AICTL_VERSION


def build_parser() -> argparse.ArgumentParser:
    """Build parser."""
    p = argparse.ArgumentParser(
        prog="aictl",
        description="AI Native Linux OS — local-first AI infrastructure CLI",
    )
    p.add_argument("--version", action="version", version=f"aictl {VERSION}")
    p.add_argument("--json", action="store_true", help="JSON output")
    p.add_argument("--state-dir", default=None, help="Override state directory")
    sub = p.add_subparsers(dest="command")

    # M0
    init.register(sub)
    doctor.register(sub)
    ps.register(sub)

    # M2
    apply.register(sub)
    down.register(sub)
    recipe.register(sub)

    # M3 (model pull is part of runtime broker)
    model.register(sub)

    # M6
    upgrade.register(sub)

    # Daemon
    serve.register(sub)

    # Cluster
    node.register(sub)
    cluster.register(sub)

    # Observability
    logs.register(sub)

    # Config
    config.register(sub)
    status.register(sub)

    # Snapshots
    snapshot.register(sub)

    # Observability
    otel.register(sub)

    # Utilities
    recommend.register(sub)
    bench.register(sub)
    setup.register(sub)
    watch.register(sub)
    proxy.register(sub)
    warmup.register(sub)
    net.register(sub)

    # GPU / Security / Deploy
    mig.register(sub)
    audit.register(sub)
    apikey.register(sub)
    image.register(sub)

    # Enterprise
    fabric.register(sub)
    context.register(sub)
    scale.register(sub)
    tenant.register(sub)
    trace.register(sub)
    cost.register(sub)
    security.register(sub)
    convert.register(sub)
    deploy.register(sub)
    completion.register(sub)
    selftest.register(sub)
    demo.register(sub)
    chat.register(sub)
    health.register(sub)
    info.register(sub)
    report.register(sub)
    meter.register(sub)
    lora.register(sub)
    gate.register(sub)
    spec.register(sub)
    log_cmd.register(sub)

    # Plugins (user-defined extensions)
    try:
        from aictl.core.plugins import register_plugins
        register_plugins(sub)
    except Exception:
        pass

    return p


def main() -> int:
    """Main."""
    parser = build_parser()
    args = parser.parse_args()
    if args.command is None:
        parser.print_help()
        return 0
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
