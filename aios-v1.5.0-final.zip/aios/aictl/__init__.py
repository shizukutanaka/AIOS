# AI Native Linux OS — aictl package
__version__ = "0.1.0"
