# aictl — AI Native Linux OS

[![CI](https://github.com/shizukutanaka/aios/actions/workflows/ci.yml/badge.svg)](https://github.com/shizukutanaka/aios/actions)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Go 1.23](https://img.shields.io/badge/go-1.23-00ADD8.svg)](https://go.dev/)

AI推論インフラの統合制御CLI。1台のGPUワークステーションからK8sクラスタまでシームレスに管理。

```
676 tests | 108 modules | 24,552 lines | zero external Python deps
```

## Install

```bash
git clone https://github.com/shizukutanaka/aios.git
cd aios
python3 -m aictl --version
```

One-liner:
```bash
curl -sSL https://raw.githubusercontent.com/shizukutanaka/aios/main/scripts/install.sh | bash
```

## 30-Second Demo (GPU不要)

```bash
python3 -m aictl init          # ハードウェア自動検出
python3 -m aictl demo --auto   # モックエンジンでフルスタック検証
python3 -m aictl recommend     # HW適合モデル推薦
```

## Features

| Feature | Description |
|---------|-------------|
| **推論エンジン** | vLLM v0.19 / SGLang v0.5 / Ollama v0.20 自動検出・ルーティング |
| **構造化出力** | guided_json, response_format, Ollama format, ツール呼び出し |
| **K8sエクスポート** | KServe, Gateway API, KEDA, HPA, Dynamo, P/D Disagg, ModelService (7形式) |
| **コスト最適化** | 7 GPU実勢価格比較, vLLMフラグ自動チューニング |
| **セキュリティ** | Cosign v3署名, セキュリティスキャナ, APIキー管理, 監査ログ |
| **MCP Server** | Claude Code/Cursorから直接操作 (10ツール) |
| **OS機能** | KVキャッシュ永続化, cgroup v2 OOM保護, メモリファブリック |
| **モニタリング** | OTel GenAI SemConv, Prometheus, Grafana ダッシュボード |

## Commands

```bash
# 基本
aictl init                             # ハードウェア検出 + 初期化
aictl doctor --deep                    # 詳細診断
aictl recommend                        # モデル推薦

# デプロイ
aictl deploy optimize <model> --gpu H100  # vLLMフラグ最適化
aictl deploy modelservice <model>         # llm-d Helm values
aictl deploy disagg <model>               # P/D分離デプロイ

# 運用
aictl cost compare                     # GPU価格比較
aictl security                         # セキュリティスキャン
aictl bench --mock -n 10               # ベンチマーク
aictl meter usage                      # トークン使用量
aictl lora add <name> --base <model>   # LoRAアダプタ

# K8s
aictl cluster gateway <stack>          # Gateway API InferencePool
aictl scale keda <stack>               # KEDA ScaledObject
```

## Architecture

```
CLI (46 Python + 29 Go)
├── Runtime   Broker → Router → AutoScaler → Fabric → Isolation
├── Daemon    22 REST API + Proxy + SLO Governor + Mock Engine
├── Stack     10 Recipes + Quadlet + KServe + Gateway API + llm-d
├── Core      Metering + Security + Cost + API Keys + Audit
├── Trust     Cosign v3 + ORAS
├── Metrics   OTel GenAI SemConv + Prometheus
└── MCP       10 tools (stdio JSON-RPC 2.0)
```

## Technology Stack

| Layer | Technology |
|-------|-----------|
| OS | bootc v1.15 (Fedora 42, immutable) |
| Container | Podman + Quadlet (systemd) |
| Inference | vLLM v0.19 / SGLang v0.5 / Ollama v0.20 |
| K8s | K3s v1.35 + KServe v0.17 + llm-d v0.5 (CNCF) |
| GPU | NVIDIA Dynamo v0.8 (KVBM + NIXL) |
| NPU | NVIDIA, Intel, AMD, Huawei Ascend, Qualcomm |
| Signing | Cosign v3 + ORAS |
| Monitoring | OTel GenAI SemConv + Prometheus + Grafana |

## Docker Quick Start

```bash
docker compose up -d
curl http://localhost:7700/v1/health   # Daemon API
curl http://localhost:9999/v1/models   # Mock engine
```

## MCP Server

```json
{
  "mcpServers": {
    "aictl": {
      "command": "python3",
      "args": ["-m", "aictl.mcp_server"]
    }
  }
}
```

## Testing

```bash
make test       # 659 Python tests
make go-test    # 17 Go tests
make gate       # Full quality gate
make demo       # E2E demo
```

## Requirements

- Python 3.11+ (stdlib only, zero deps)
- Linux (any distro)
- Optional: Podman, NVIDIA GPU, Ollama

## License

MIT
