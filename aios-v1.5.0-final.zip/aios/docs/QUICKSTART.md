# AI OS Quick Start

## Install

```bash
# Option 1: One-line install
curl -sSL https://raw.githubusercontent.com/shizukutanaka/aios/main/scripts/install.sh | bash

# Option 2: pip install
git clone https://github.com/shizukutanaka/aios.git
cd aios && pip install -e .

# Option 3: Run directly
git clone https://github.com/shizukutanaka/aios.git
cd aios && python3 -m aictl --version
```

## First Run (30 seconds)

```bash
aictl init           # Initialize node (auto-detects GPU)
aictl doctor         # System diagnosis
aictl demo --auto    # Full-stack demo (no GPU needed!)
```

## Deploy a Model (2 minutes)

```bash
# CPU-only (Ollama)
aictl recipe run local-chat     # → http://localhost:3000

# With GPU (vLLM)
aictl recipe run local-gpu-chat

# Check what models fit your hardware
aictl recommend
```

## Monitor

```bash
aictl status         # Dashboard
aictl watch          # Live monitoring
aictl health         # Full health check
aictl report         # System assessment (Markdown)
```

## Scale to K8s

```bash
aictl cluster promote                           # Plan K3s upgrade
aictl cluster export team-rag > kserve.yaml     # KServe manifests
aictl cluster gateway team-rag > gw.yaml        # Gateway API
aictl scale keda my-deploy --threshold 5        # KEDA autoscaler
```

## Key Commands

| Command | Purpose |
|---------|---------|
| `aictl demo --auto` | Full-stack demo (mock engine) |
| `aictl chat --mock` | Interactive chat with mock engine |
| `aictl doctor --deep` | Deep system diagnosis |
| `aictl deploy plan <model>` | Zero-config resource estimation |
| `aictl cost compare` | GPU pricing comparison |
| `aictl security` | Security scan (0-100 score) |
| `aictl lora add <n> --base <m>` | Register LoRA adapter |
| `aictl meter usage` | Token usage by entity |
| `aictl fabric detect` | Memory tier detection |
| `aictl selftest` | Run 449+ tests |
